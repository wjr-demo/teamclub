netease
├── CheckSumBuilder.java #签名类
└── SMSTest.java #主测试方法，使用Play WS调用
